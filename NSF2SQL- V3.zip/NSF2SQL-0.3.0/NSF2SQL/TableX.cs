﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace NSF2SQL
{
    public class TableX
    {
        [XmlElement("Key")]
        public string key;

        [XmlElement("Value")]
        public Table table;

        public TableX() { }
    }
}
